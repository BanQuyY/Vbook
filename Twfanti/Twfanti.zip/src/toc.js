function execute(url) {
	const yUrl = url.replace('m.twfanti.com/book/','m.twfanti.com/');
	const yUrl = yUrl.replace('.html','/dir.html');
	
    /////////const idBook = url.match(/\d+/)[0];
    /////////const yUrl = 'https://www.yushubo.net/list_other_'+idBook+'.html';
    var doc = fetch(yUrl).html();
    var el = doc.select("a")
    const list = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        list.push({
            name: e.attr("title"),
            url: e.attr("href"),
            host: "https://m.twfanti.com"
        })
    }
    return Response.success(list)
}