function execute(url, page) {
    if (!page) page = '1';
    let response = fetch(url + '&p=' + page);
    if (response.ok) {
        let doc = response.html();
        let next = doc.select(".pagination").select("li.active + li").text();
        let el = doc.select("#searchviewdiv a.booksearch");
        let data = [];

        function toCapitalize(sentence) {
            const words = sentence.split(" ");
            return words.map((word) => {
                return word[0].toUpperCase() + word.substring(1);
            }).join(" ");
        }

        function extractNumber(text) {
            // Trích xuất số từ chuỗi (ví dụ "211k" -> 211000, "280" -> 280)
            text = text.trim().toLowerCase();
            if (text.endsWith('k')) {
                return parseFloat(text.slice(0, -1)) * 1000;
            }
            return parseFloat(text);
        }

        el.forEach(e => {
            let img = e.select("img").first().attr("src");
            
            // Lấy view count (số đầu tiên)
            let viewCount = extractNumber(e.select(".info span:nth-child(1)").first().text());
            
            // Lấy chapter count (số thứ ba)
            let chapterCount = extractNumber(e.select(".info span:nth-child(3)").first().text());
            
            if (img.startsWith('//')) {
                img = img.replace('//', 'https://');
            }

            // Kiểm tra điều kiện: views > 5000 và chapters < 150
            if (viewCount > 5000 && chapterCount < 500) {
                data.push({
                    name: toCapitalize(e.select(".searchbooktitle").first().text()),
                    link: e.select("a").first().attr("href"),
                    cover: img,
                    description: e.select(".info span").first().text() + "⚡️" + 
                               e.select(".info span:nth-child(3)").first().text() + "c",
                    host: "http://14.225.254.182"
                });
            }
        });
        return Response.success(data, next);
    }
    return null;
}