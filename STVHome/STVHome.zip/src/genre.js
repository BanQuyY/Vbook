function execute() {
    return Response.success([
    {title: "69shu New 100", input: "http://sangtacviet.com/?find=&host=69shu&minc=0&sort=update&step=1&tag=", script: "gen.js"},
    {title: "69shu New 200", input: "http://sangtacviet.com/?find=&host=69shu&minc=100&sort=update&step=1&tag=", script: "gen3.js"},
    
        
    ]);
}