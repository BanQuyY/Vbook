function execute() {
    return Response.success([
    {title: "Fanqie New 100", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=0&sort=update&step=1&tag=", script: "gen2.js"},
    {title: "69shu New 100", input: "http://sangtacviet.vip/?find=&host=69shu&minc=0&sort=update&step=1&tag=", script: "gen2.js"},
    {title: "69shu New 200", input: "http://sangtacviet.vip/?find=&host=69shu&minc=0&sort=update&tag=", script: "gen3.js"},
    {title: "69shu nhapkho", input: "http://sangtacviet.vip/?find=&host=69shu&minc=100&sort=new&step=1&tag=", script: "gen3.js"},
    {title: "Qidian New 200", input: "http://sangtacviet.vip/?find=&host=qidian&minc=0&sort=update&tag=", script: "gen3.js"},
    {title: "Qidian view", input: "http://sangtacviet.vip/?find=&host=qidian&minc=0&sort=update&tag=", script: "gen.js"},
    {title: "Qidian TheoDoi", input: "http://sangtacviet.vip/?find=&host=qidian&minc=0&sort=bookmarked&step=1&tag=", script: "gen.js"},
    {title: "Fanqie New HH", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=0&sort=update&step=1&tag=huyenhuyennaodong,", script: "gen4.js"},
    {title: "Fanqie New 200", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=0&sort=update&step=1&tag=", script: "gen4.js"},
    
        
    ]);
}