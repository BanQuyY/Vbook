function execute() {
    return Response.success([
    {title: "69shu Tuần", input: "http://sangtacviet.com/?find=&host=69shu&minc=0&sort=viewweek&step=1&tag=", script: "gen3.js"},
    {title: "69shu New", input: "http://sangtacviet.com/?find=&host=69shu&minc=0&sort=update&step=1&tag=", script: "gen3.js"},
    {title: "Qidian Tuần", input: "http://sangtacviet.com/?find=&host=qidian&minc=0&sort=viewweek&step=1&tag=", script: "gen2.js"},
    {title: "Qidian New", input: "http://sangtacviet.com/?find=&host=qidian&minc=0&sort=update&step=1&tag=", script: "gen2.js"},       
        {title: "Fanqie New", input: "http://sangtacviet.com/?find=&host=fanqie&minc=0&sort=update&step=1&tag=", script: "gen2.js"},
        {title: "Fanqie Tuần", input: "http://sangtacviet.com/?find=&host=fanqie&minc=0&sort=viewweek&step=1&tag=", script: "gen2.js"},
        {title: "Fanqie Ngày", input: "https://sangtacviet.pro/?find=&host=fanqie&minc=0&sort=viewday&step=1&tag=", script: "gen.js"},
        {title: "Qidian Ngày", input: "https://sangtacviet.com/?find=&host=qidian&minc=0&sort=viewday&step=1&tag=", script: "gen.js"},
        
    ]);
}