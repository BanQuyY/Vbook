function execute() {
    return Response.success([
    {title: "Fanqie New 100", input: "http://14.225.254.182/?find=&host=fanqie&minc=0&sort=update&step=1&tag=", script: "gen2.js"},
    {title: "Fanqie ngày", input: "http://14.225.254.182/?find=&host=fanqie&minc=0&sort=viewday&step=1&tag=", script: "gen3.js"},
    {title: "qidian ngày", input: "http://14.225.254.182/?find=&host=qidian&minc=0&sort=viewday&step=1&tag=", script: "gen3.js"},
    {title: "69shu", input: "http://14.225.254.182/?find=&host=69shu&minc=0&sort=viewweek&step=1&tag=", script: "gen.js"},
    {title: "Qidian 200", input: "http://14.225.254.182/?find=&host=qidian&minc=0&sort=update&tag=", script: "gen3.js"},
    {title: "Qidian 100", input: "http://14.225.254.182/?find=&host=qidian&minc=0&sort=update&tag=", script: "gen2.js"},
    {title: "Fanqie 200", input: "http://14.225.254.182/?find=&host=fanqie&minc=0&sort=update&step=1&tag=", script: "gen3.js"},
    
        
    ]);
}