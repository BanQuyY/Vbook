function execute() {
    return Response.success([
        {title: "Fanqie Tuần", input: "https://sangtacviet.pro/?find=&host=fanqie&minc=0&sort=viewweek&step=1&tag=", script: "gen.js"},
        {title: "Fanqie Ngày", input: "https://sangtacviet.pro/?find=&host=fanqie&minc=0&sort=viewday&step=1&tag=", script: "gen.js"},
        {title: "Qidian Tuần", input: "https://sangtacviet.com/?find=&host=qidian&minc=0&sort=viewweek&step=1&tag=", script: "gen.js"},
        {title: "Qidian Ngày", input: "https://sangtacviet.com/?find=&host=qidian&minc=0&sort=viewday&step=1&tag=", script: "gen.js"},
        {title: "Huyền huyễn", input: "https://sangtacviet.com/?find=&minc=0&category=hh&tag=", script: "gen.js"},
        {title: "Đô thị", input: "https://sangtacviet.com/?find=&minc=0&category=dt&tag=", script: "gen.js"},
        {title: "Ngôn tình", input: "https://sangtacviet.com/?find=&minc=0&category=nt&tag=", script: "gen.js"},
        {title: "Võng du", input: "https://sangtacviet.com/?find=&minc=0&category=vd&tag=", script: "gen.js"},
        {title: "Khoa học viễn tưởng", input: "https://sangtacviet.com/?find=&minc=0&category=kh&tag=", script: "gen.js"},
        {title: "Lịch sử", input: "https://sangtacviet.com/?find=&minc=0&category=lsa&tag=", script: "gen.js"},
        {title: "Đồng nhân", input: "https://sangtacviet.com/?find=&minc=0&category=dn&tag=", script: "gen.js"},
        {title: "Dị năng", input: "https://sangtacviet.com/?find=&minc=0&category=dna&tag=", script: "gen.js"},
        {title: "Linh dị", input: "https://sangtacviet.com/?find=&minc=0&category=ld&tag=", script: "gen.js"},
        {title: "Light Novel", input: "https://sangtacviet.com/?find=&minc=0&category=ln&tag=", script: "gen.js"},
    ]);
}