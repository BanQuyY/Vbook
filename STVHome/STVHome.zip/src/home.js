function execute() {
    return Response.success([
        {title: "Qidian 1000", input: "http://14.225.254.182/?find=&host=qidian&minc=0&sort=update&tag=", script: "gen4.js"},
    
        
    ]);
}