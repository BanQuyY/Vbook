function execute() {
    return Response.success([
    {title: "Fanqie CS", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=0&sort=update&step=1&tag=causinh,", script: "gen4.js"},
    {title: "Fanqie New HH", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=0&sort=update&step=1&tag=huyenhuyennaodong,", script: "gen4.js"},
    {title: "Fanqie New 200", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=0&sort=update&step=1&tag=", script: "gen4.js"}
        
    ]);
}