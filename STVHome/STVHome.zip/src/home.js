function execute() {
    return Response.success([
    {title: "Fanqie CS", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=0&sort=update&step=1&tag=causinh,", script: "gen4.js"},
    
        
    ]);
}