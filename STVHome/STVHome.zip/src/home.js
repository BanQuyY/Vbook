function execute() {
    return Response.success([
        {title: "Qidian 200", input: "http://14.225.254.182/?find=&host=qidian&minc=0&sort=update&tag=", script: "gen3.js"},
    
        
    ]);
}