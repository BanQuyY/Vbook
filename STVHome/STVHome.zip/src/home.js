function execute() {
    return Response.success([
    {title: "Fanqie theo dõi", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=0&sort=following&step=1&tag=", script: "gen5.js"},
    {title: "Fanqie New 100", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=0&sort=update&step=1&tag=", script: "gen2.js"},
    {title: "Fanqie New 200", input: "http://sangtacviet.vip/?find=&host=fanqie&minc=100&sort=update&step=1&tag=", script: "gen3.js"}
        
    ]);
}