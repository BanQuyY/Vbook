function execute(url) {
	let response = fetch(url, {
        headers: {
            'user-agent': UserAgent.android()
        }
    });
    const reader = 'https://novel.snssdk.com/api/novel/book/reader/full/v1/?group_id=';
    if (response.ok) {
        let res_json = response.json();
        console.log(res_json)        
        let allBook = res_json.data.item_data_list;
        
        const book = [];
        for (let i = 0; i < allBook.length; i++) {
            let item = allBook[i];
            
            book.push({
                    name: item['title'],           
                    url: reader+item['item_id'] + "&item_id=" + item['item_id'] + "&aid=1976",
                    host: "https://novel.snssdk.com"
        })
        }
        
        return Response.success(book);  
    }
    return null;
}