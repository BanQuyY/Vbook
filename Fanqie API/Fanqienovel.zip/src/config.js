let config_host = "https://fanqienovel.com"
let config_host2 = "https://fq.beitai.vip";
if (typeof host !== "undefined") {
    config_host2 = host
}