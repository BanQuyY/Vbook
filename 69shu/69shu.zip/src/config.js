    var host = 'https://www.69xinshu.com';
