function execute() {
    return Response.success([
        {title: "最新更新", input: "/last", script: "update.js"},    
        {title: "玄幻魔法", input: "/ajax_novels/full/1/{0}.htm", script: "gen.js"},
        
    ]);
}