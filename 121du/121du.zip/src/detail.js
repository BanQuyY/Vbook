function execute(url) {
    const yUrl = url.replace('m.','www.');
    const doc = fetch(yUrl).html();
    
    return Response.success({
        name: doc.select("h1").text(),
        cover: doc.select(".book-img img").first().attr('src'),
        author: doc.select("#bookinfo p b a").first().text(),
        description: doc.select(".book-intro").html(),
        detail: doc.select(".booktitle p").html(),
        category: doc.select(".booktitle p").html(),
        host: "https://www.yushubo.net"
    });
}