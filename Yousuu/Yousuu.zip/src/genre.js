function execute() {
    return Response.success([
        {title: "玄幻☀️", input: "https://www.yousuu.com/bookstore/?channel=0&classId=2&tag&countWord&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "10-30", input: "https://www.yousuu.com/bookstore/?channel=0&classId=2&tag&countWord=1&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "30-60", input: "https://www.yousuu.com/bookstore/?channel=0&classId=2&tag&countWord=2&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "60-100", input: "https://www.yousuu.com/bookstore/?channel=0&classId=2&tag&countWord=3&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "奇幻☀️", input: "https://www.yousuu.com/bookstore/?channel=0&classId=3&tag&countWord&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "10-30", input: "https://www.yousuu.com/bookstore/?channel=0&classId=3&tag&countWord=1&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "30-60", input: "https://www.yousuu.com/bookstore/?channel=0&classId=3&tag&countWord=2&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "60-100", input: "https://www.yousuu.com/bookstore/?channel=0&classId=3&tag&countWord=3&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "武侠☀️", input: "https://www.yousuu.com/bookstore/?channel=0&classId=4&tag&countWord&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "10-30", input: "https://www.yousuu.com/bookstore/?channel=0&classId=4&tag&countWord=1&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "30-60", input: "https://www.yousuu.com/bookstore/?channel=0&classId=4&tag&countWord=2&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "60-100", input: "https://www.yousuu.com/bookstore/?channel=0&classId=4&tag&countWord=3&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "仙侠☀️", input: "https://www.yousuu.com/bookstore/?channel=0&classId=5&tag&countWord&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "10-30", input: "https://www.yousuu.com/bookstore/?channel=0&classId=5&tag&countWord=1&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "30-60", input: "https://www.yousuu.com/bookstore/?channel=0&classId=5&tag&countWord=2&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "60-100", input: "https://www.yousuu.com/bookstore/?channel=0&classId=5&tag&countWord=3&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "都市☀️", input: "https://www.yousuu.com/bookstore/?channel=0&classId=6&tag&countWord&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "10-30", input: "https://www.yousuu.com/bookstore/?channel=0&classId=6&tag&countWord=1&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "30-60", input: "https://www.yousuu.com/bookstore/?channel=0&classId=6&tag&countWord=2&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "60-100", input: "https://www.yousuu.com/bookstore/?channel=0&classId=6&tag&countWord=3&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "游戏☀️", input: "https://www.yousuu.com/bookstore/?channel=0&classId=11&tag&countWord&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "10-30", input: "https://www.yousuu.com/bookstore/?channel=0&classId=11&tag&countWord=1&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "30-60", input: "https://www.yousuu.com/bookstore/?channel=0&classId=11&tag&countWord=2&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "60-100", input: "https://www.yousuu.com/bookstore/?channel=0&classId=11&tag&countWord=3&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "科幻☀️", input: "https://www.yousuu.com/bookstore/?channel=0&classId=13&tag&countWord&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "10-30", input: "https://www.yousuu.com/bookstore/?channel=0&classId=13&tag&countWord=1&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "30-60", input: "https://www.yousuu.com/bookstore/?channel=0&classId=13&tag&countWord=2&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        {title: "60-100", input: "https://www.yousuu.com/bookstore/?channel=0&classId=13&tag&countWord=3&status=0&update=1&sort=scorer&page=", script: "gen2.js"},
        

    ]);
}