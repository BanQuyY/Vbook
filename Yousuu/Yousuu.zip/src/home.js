function execute() {
    return Response.success([
     {title: "玄幻", input: "https://www.yousuu.com/bookstore/?channel=0&classId=2&tag&countWord&status=0&update=0&sort&page=", script: "gen2.js"},
        
    ]);
}