function execute(url) {
    let response = fetch(url + "/");
    if (response.ok) {

        let doc = response.html('gbk');
        let coverImg = doc.select('meta[property="og:image"]').attr("content");
        if (coverImg.startsWith("//")) {
            coverImg = "https:" + coverImg;
        }
        return Response.success({
            name: doc.select('meta[property="og:novel:book_name"]').attr("content"),
            cover: coverImg,
            author: doc.select('meta[property="og:novel:author"]').attr("content"),
            description: doc.select('meta[property="og:description"]').attr("content"),
            detail: "作者：" + doc.select('meta[property="og:novel:author"]').attr("content"),
            host: "https://www.778buy.cc/"
        });
    }
    return null;
}