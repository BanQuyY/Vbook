function execute(url) {
    let response = fetch(url.replace('m.','www.'));

    if (response.ok) {
        let doc = response.html('gbk');
        let htm = doc.select("#content").html();
        htm = htm.replace(/\&nbsp;/g, "").replace(/\<\a(.*?)<\/a>/g,'').replace(/【.*?www.yeguoyuedu.com.*?】/g,'').replace(/。/g,"。<br><br>");
        return Response.success(htm);
    }
    return null;
}