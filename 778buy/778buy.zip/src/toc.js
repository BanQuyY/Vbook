function execute(url) {
    
    var doc = fetch(url).html('gbk');
    var el = doc.select("#defaulthtml4 td a")
    const list = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        list.push({
            name: e.text(),
            url: e.attr("href"),
            host: "https://www.778buy.cc/"
        })
    }
    return Response.success(list)
    

}
