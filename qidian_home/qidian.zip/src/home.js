function execute() {
    return Response.success([
         {title: "Tuần Phiếu", input: "https://www.qidian.com/all/action0-update1-orderId9/", script: "gen.js"},
        
    ]);
}